create table Bid_Rep(
	bssn int,
	sales_num int,
	foreign key (bssn) references Employee (ssn)
);

insert into Bid_Rep (bssn, sales_num) values (541848673, 3604);
insert into Bid_Rep (bssn, sales_num) values (661190266, 2957);
insert into Bid_Rep (bssn, sales_num) values (796328349, 2400);
insert into Bid_Rep (bssn, sales_num) values (219288487, 324);

insert into Bid_Rep (bssn, sales_num) values (802443958, 4392);
insert into Bid_Rep (bssn, sales_num) values (584277178, 3462);
insert into Bid_Rep (bssn, sales_num) values (470586541, 2741);
insert into Bid_Rep (bssn, sales_num) values (353024433, 2913);

insert into Bid_Rep (bssn, sales_num) values (117320864, 6727);
insert into Bid_Rep (bssn, sales_num) values (346259342, 900);
insert into Bid_Rep (bssn, sales_num) values (560751965, 3498);
insert into Bid_Rep (bssn, sales_num) values (107909201, 4369);

insert into Bid_Rep (bssn, sales_num) values (746749350, 9001);
insert into Bid_Rep (bssn, sales_num) values (894085150, 6200);
insert into Bid_Rep (bssn, sales_num) values (156743744, 2158);

insert into Bid_Rep (bssn, sales_num) values (456506149, 9560);
insert into Bid_Rep (bssn, sales_num) values (192496284, 4969);
insert into Bid_Rep (bssn, sales_num) values (344342341, 3671);
