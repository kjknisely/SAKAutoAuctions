create table Driver(
	dssn int,
	license_num int,
	foreign key (dssn) references Employee (ssn)
);

insert into Driver (dssn, license_num) values (290598779, 714629877);
insert into Driver (dssn, license_num) values (486491278, 941697749);
insert into Driver (dssn, license_num) values (936044654, 741662378);
insert into Driver (dssn, license_num) values (352308146, 134897238);
insert into Driver (dssn, license_num) values (563248510, 713937279);

insert into Driver (dssn, license_num) values (760597127, 719838184);
insert into Driver (dssn, license_num) values (323771018, 364894916);
insert into Driver (dssn, license_num) values (856788069, 481783799);
insert into Driver (dssn, license_num) values (141462261, 698716249);

insert into Driver (dssn, license_num) values (569961477, 259844697);
insert into Driver (dssn, license_num) values (207347219, 354978166);
insert into Driver (dssn, license_num) values (631899888, 365445198);
insert into Driver (dssn, license_num) values (187413366, 871987379);

insert into Driver (dssn, license_num) values (501805751, 719879873);
insert into Driver (dssn, license_num) values (666257142,  187173879);
insert into Driver (dssn, license_num) values (663872597, 489798467);
insert into Driver (dssn, license_num) values (616166991, 364899217);

insert into Driver (dssn, license_num) values (926712707, 165781376);
insert into Driver (dssn, license_num) values (226450617, 356275442);
insert into Driver (dssn, license_num) values (867421136, 689916154);
insert into Driver (dssn, license_num) values (993216166, 178657779);
insert into Driver (dssn, license_num) values (693872023, 456953187);

